# VBLinLogit unit tests

Each unit test script is named after the function in the [`src`](../src) folder that it tests. Run
```Matlab
vb_tests
```
At the MATLAB/Octave command line to run all the test.